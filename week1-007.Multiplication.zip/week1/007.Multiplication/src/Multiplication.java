public class Multiplication {

    public static void main(String[] args) {

        int a = 1337;
        int b = 42;

        // Program your solution here. Remember to use variables a and b!
    }

}
